'use strict'
const Point = require('./util/Point');
let p = new Point(1,2);
console.log(p.toString());



