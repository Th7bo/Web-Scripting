'use strict'

let ostrich = document.getElementById("gertrude");
console.log(ostrich.src);
