'use strict'
let cat = document.querySelector("img");
let angle = Math.PI / 2;

function animate(time, lastTime) {
    if (lastTime != null) {         
        angle += (time - lastTime) * 0.0001;
    }
    cat.style.top = (Math.sin(angle) * 600) + "px";
    cat.style.left = (Math.cos(angle) * 600) + "px";
    console.log(cat.style);
    requestAnimationFrame(newTime => animate(newTime, time));
}

requestAnimationFrame(animate);
