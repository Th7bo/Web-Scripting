'use strict'
window.addEventListener("click", () => {
    console.log("You knocked?");
});