'use strict'
let reds = document.getElementsByClassName("red");
for (let red of reds){
    console.log(red.textContent);
    
}
