'use strict'
let links = document.getElementsByTagName("a");
for (let link of links){
    console.log(link.href);
}
