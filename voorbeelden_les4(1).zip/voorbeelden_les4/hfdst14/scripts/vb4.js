'use strict'
let firstRed = document.getElementsByClassName("red")[0];
console.log(firstRed.textContent); // My home page
