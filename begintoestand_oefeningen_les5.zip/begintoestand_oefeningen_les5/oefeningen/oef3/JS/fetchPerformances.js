'use strict'
window.addEventListener("load", init);
function init() {
    
}

function handleGetAllPerformances() {
    let url = 'http://localhost:3000/performances/';
    
}

function handleGetAllPerformancesByDate() {
    
    let url = 'http://localhost:3000/performances/';
    
}
function handleGetPerformance() {
    let url = 'http://localhost:3000/performances/';
    
}



function handlePostPerformance() {
    let url = 'http://localhost:3000/performances/';
    
}


function makeElementEmpty(element) {
    while (element.hasChildNodes()) {
        element.removeChild(element.firstChild);
    }
}


