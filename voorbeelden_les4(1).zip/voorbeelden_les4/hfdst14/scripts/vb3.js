'use strict'
let firstLink = document.getElementsByTagName("a")[0];
console.log(firstLink.href); // http://destandaard.be